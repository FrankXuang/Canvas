# 特效入門 | <Project 7> 結合物件跟繪圖製作遊戲Agar.io （上）

A Pen created on CodePen.io. Original URL: [https://codepen.io/frank890417/pen/aGOgvq](https://codepen.io/frank890417/pen/aGOgvq).

