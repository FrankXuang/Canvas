# Recording: Canvas drawImage()

A Pen created on CodePen.io. Original URL: [https://codepen.io/punkydrewster713/pen/ExPLXGE](https://codepen.io/punkydrewster713/pen/ExPLXGE).

This is the code for my tutorial video showing different usages of HTML Canvas `drawImage`.
See the video here:

https://youtu.be/jEUuM5bRAzw