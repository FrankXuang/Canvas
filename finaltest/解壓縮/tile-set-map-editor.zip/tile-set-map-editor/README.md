# Tile Set Map Editor

A Pen created on CodePen.io. Original URL: [https://codepen.io/punkydrewster713/pen/QWymBGy](https://codepen.io/punkydrewster713/pen/QWymBGy).

Here's an example of a Tile based Map editor. The end result can be saved as a .png. You could also use this concept to dynamically place tiles in any HTML app or game.

Video Tutorial:
https://youtu.be/IYgZMIB7_PM